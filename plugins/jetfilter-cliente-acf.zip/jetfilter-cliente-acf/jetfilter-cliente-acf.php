<?php
/*
Plugin Name: Filtro por Cliente ACF (Elementor + ACF)
Description: Filtra o CPT 'iptu' por cliente (campo ACF 'gp_cliente') em um Loop Grid do Elementor, usando shortcode e query ID personalizada.
Version: 1.4
Author: Jean Carlos - UIOS
*/

// 1. Aplica o filtro ao Query ID do Elementor Loop Grid
add_action('elementor/query/cliente_documentos', function ($query) {
    if (!isset($_GET['meta_query_gp_cliente']) || !is_numeric($_GET['meta_query_gp_cliente'])) {
        return;
    }

    $cliente_id = intval($_GET['meta_query_gp_cliente']);

    // Pega meta_query existente, se houver
    $existing_meta_query = (array) $query->get('meta_query');

    $existing_meta_query[] = [
        'key' => 'gp_cliente',
        'value' => $cliente_id,
        'compare' => '='
    ];

    $query->set('meta_query', $existing_meta_query);
});

// 2. Shortcode para gerar o filtro <select> com usuários com role "cliente"
add_shortcode('filtro_cliente_acf', function () {
    $clientes = get_users([
        'role' => 'cliente',
        'fields' => ['ID', 'display_name']
    ]);

    $selected = isset($_GET['meta_query_gp_cliente']) ? intval($_GET['meta_query_gp_cliente']) : '';

    ob_start(); ?>
    <form method="get" id="filtro-cliente-form" style="margin-bottom: 20px;">
        <label for="meta_query_gp_cliente"><strong>Filtrar por cliente:</strong></label>
        <select name="meta_query_gp_cliente" id="meta_query_gp_cliente" onchange="this.form.submit();">
            <option value="">Todos</option>
            <?php foreach ($clientes as $cliente): ?>
                <option value="<?= esc_attr($cliente->ID) ?>" <?= selected($selected, $cliente->ID, false) ?>>
                    <?= esc_html($cliente->display_name) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </form>
    <?php return ob_get_clean();
});
