<?php
/**
 * Plugin Name: Royal Gestão de Documentos - Formulário
 * Description: Gera formulário para cadastro de documentos IPTU com criação opcional de cliente.
 * Version: 2.1.0
 * Author: UIOS
 */

defined('ABSPATH') || exit;

// Carrega módulos
require_once plugin_dir_path(__FILE__) . 'includes/handlers.php';
require_once plugin_dir_path(__FILE__) . 'includes/helpers.php';
require_once plugin_dir_path(__FILE__) . 'includes/render-form.php';
require_once plugin_dir_path(__FILE__) . 'includes/logger.php';

// Registra shortcode
add_shortcode('formulario_iptu', 'royal_render_formulario_iptu');

