<?php
defined('ABSPATH') || exit;

function royal_render_formulario_iptu() {
    // Carrega dados necessários para os selects
    $clientes = get_users(['role' => 'cliente']);
    $tax_cidades = get_terms(['taxonomy' => 'tax_cidade', 'hide_empty' => false]);
    if ( is_wp_error($tax_cidades) ) $tax_cidades = [];
    $empreendimentos = get_terms(['taxonomy' => 'empreendimento', 'hide_empty' => false]);
    $apartamentos = get_terms(['taxonomy' => 'apartamento', 'hide_empty' => false]);

    // Processa o formulário
    [$tipo_mensagem, $mensagem] = function_exists('royal_handle_formulario_iptu')
        ? royal_handle_formulario_iptu()
        : ['', ''];

    ob_start();
    ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/alpinejs" defer></script>
    <div class="max-w-2xl mx-auto bg-white shadow-xl rounded-lg p-8"
         x-data="{
            novoCliente: false,
            novoEmpreendimento: false,
            novoApartamento: false,
            loading: false,
            feedback: '',
            feedbackColor: '',
            resetFeedback() { this.feedback = ''; this.feedbackColor = ''; }
         }">
      <h2 class="text-2xl font-bold mb-8 text-center text-gray-800">Cadastro de Documento IPTU</h2>
      <?php if ($mensagem): ?>
        <div class="p-4 mb-4 rounded text-lg font-semibold
            <?= $tipo_mensagem === 'sucesso' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700' ?>">
          <?= esc_html($mensagem) ?>
        </div>
      <?php endif; ?>
      <form method="post" enctype="multipart/form-data" autocomplete="on"
        @submit="
          resetFeedback();
          let required = ['arquivo','vencimento','tax_cidade','empreendimento','apartamento'];
          if (!novoCliente) required.push('cliente');
          if (novoCliente) required.push('novo_cliente_nome','cpf_do_cliente');
          let valid = required.every(id => {
            let el = $refs[id];
            if (el && !el.value) { el.classList.add('border-red-500'); return false; }
            else if (el) { el.classList.remove('border-red-500'); }
            return true;
          });
          if (!valid) {
            feedback = 'Por favor, preencha todos os campos obrigatórios.';
            feedbackColor = 'red';
            $event.preventDefault();
            return;
          }
          loading = true;
        ">
        <?php wp_nonce_field('formulario_iptu', 'formulario_iptu_nonce'); ?>
        <input type="hidden" name="novo_cliente" :value="novoCliente ? 1 : 0">

        <div class="space-y-4">
          <!-- Título -->
          <div>
            <label for="titulo" class="block text-lg font-semibold text-gray-700 mb-1">Título do Documento</label>
            <input type="text" name="titulo" id="titulo" x-ref="titulo"
                   class="w-full p-3 border border-gray-300 rounded-md shadow-sm bg-gray-100 text-gray-500"
                   readonly tabindex="-1" autocomplete="off">
          </div>

          <!-- Upload -->
          <div>
            <label for="arquivo" class="block text-lg font-semibold text-gray-700 mb-1">IPTU (arquivo para download)</label>
            <input type="file" name="arquivo" id="arquivo" x-ref="arquivo"
                   class="w-full p-3 border border-gray-300 rounded-md shadow-sm bg-white" required accept="application/pdf">
          </div>

          <!-- Cliente -->
          <div>
            <div class="flex items-center justify-between mb-1">
              <label class="block text-lg font-semibold text-gray-700">Cliente</label>
              <label class="flex items-center gap-2 text-sm text-gray-600">
                <input type="checkbox" x-model="novoCliente" class="form-checkbox h-5 w-5 text-blue-600">
                <span>Adicionar novo cliente</span>
              </label>
            </div>
            <template x-if="!novoCliente">
              <select name="cliente" id="cliente" x-ref="cliente"
                      class="w-full p-3 border border-gray-300 rounded-md shadow-sm bg-white" required>
                <option value="">Selecione um cliente</option>
                <?php foreach ($clientes as $cliente): ?>
                  <option value="<?= esc_attr($cliente->ID) ?>"><?= esc_html($cliente->display_name) ?></option>
                <?php endforeach; ?>
              </select>
            </template>
            <template x-if="novoCliente">
              <div class="grid grid-cols-1 md:grid-cols-2 gap-2 mt-2">
                <input type="text" name="novo_cliente_nome" x-ref="novo_cliente_nome" placeholder="Nome completo" class="p-3 border border-gray-300 rounded-md shadow-sm" required>
                <input type="text" name="cpf_do_cliente" x-ref="cpf_do_cliente" placeholder="CPF" class="p-3 border border-gray-300 rounded-md shadow-sm" required pattern="\d{11}" maxlength="11">
              </div>
            </template>
          </div>

          <!-- Cidade -->
          <div>
            <label for="tax_cidade" class="block text-lg font-semibold text-gray-700 mb-1">Cidade</label>
            <select name="tax_cidade" id="tax_cidade" x-ref="tax_cidade"
                    class="w-full p-3 border border-gray-300 rounded-md shadow-sm bg-white" required>
              <option value="">Selecione a cidade</option>
              <?php foreach ($tax_cidades as $tax_cidade): ?>
                <option value="<?= esc_attr($tax_cidade->term_id) ?>">
                  <?= esc_html($tax_cidade->name) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <!-- Empreendimento -->
          <div>
            <label for="empreendimento" class="block text-lg font-semibold text-gray-700 mb-1">Empreendimento</label>
            <select name="empreendimento" id="empreendimento" x-ref="empreendimento"
                    class="w-full p-3 border border-gray-300 rounded-md shadow-sm bg-white" required>
              <option value="">Selecione o empreendimento</option>
              <?php foreach ($empreendimentos as $emp): ?>
                <option value="<?= esc_attr($emp->term_id) ?>"><?= esc_html($emp->name) ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <!-- Apartamento -->
          <div>
            <label for="apartamento" class="block text-lg font-semibold text-gray-700 mb-1">Apartamento</label>
            <select name="apartamento" id="apartamento" x-ref="apartamento"
                    class="w-full p-3 border border-gray-300 rounded-md shadow-sm bg-white" required>
              <option value="">Selecione o apartamento</option>
              <?php foreach ($apartamentos as $apt): ?>
                <option value="<?= esc_attr($apt->term_id) ?>"><?= esc_html($apt->name) ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <!-- Vencimento -->
          <div>
            <label for="vencimento" class="block text-lg font-semibold text-gray-700 mb-1">Data de Vencimento</label>
            <input type="date" name="vencimento" id="vencimento" x-ref="vencimento"
                   class="w-full p-3 border border-gray-300 rounded-md shadow-sm bg-white" required>
          </div>
        </div>

        <!-- Botão Enviar -->
        <div class="text-center mt-8">
          <button type="submit" :disabled="loading"
                  class="bg-green-600 hover:bg-green-700 text-white py-3 px-8 rounded-md text-lg font-semibold transition duration-300 ease-in-out cursor-pointer"
                  x-text="loading ? 'Enviando...' : 'Enviar Documento'"></button>
          <div x-show="feedback" :class="{
                'text-green-600': feedbackColor === 'green',
                'text-red-600': feedbackColor === 'red',
                'text-blue-600': feedbackColor === 'blue'
              }" class="mt-4 text-lg font-semibold" x-text="feedback"></div>
        </div>
      </form>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
      function generateUUID() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
          var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
          return v.toString(16);
        });
      }
      var titulo = document.getElementById('titulo');
      if (titulo) titulo.value = generateUUID();
    });
    </script>
    <?php

    return ob_get_clean();
}