<?php
defined('ABSPATH') || exit;

function royal_handle_formulario_iptu() {
    if (
        $_SERVER['REQUEST_METHOD'] !== 'POST' ||
        empty($_POST['formulario_iptu_nonce']) ||
        !wp_verify_nonce($_POST['formulario_iptu_nonce'], 'formulario_iptu')
    ) {
        return [null, null];
    }

    // ----------------------------
    // 1. Criação do cliente, se necessário
    // ----------------------------
    $cliente_id = sanitize_text_field($_POST['cliente'] ?? '');

    if (!empty($_POST['novo_cliente']) && $_POST['novo_cliente'] === '1') {
        $nome = sanitize_text_field($_POST['novo_cliente_nome']);
        $cpf  = sanitize_text_field($_POST['cpf_do_cliente']);

        $novo_cliente_id = wp_insert_user([
            'user_login'   => sanitize_title($nome) . '_' . time(),
            'user_pass'    => wp_generate_password(),
            'user_email'   => $cpf . '@email.fake',
            'first_name'   => $nome,
            'display_name' => $nome,
            'role'         => 'cliente'
        ]);

        if (is_wp_error($novo_cliente_id)) {
            return ['erro', 'Erro ao criar cliente: ' . $novo_cliente_id->get_error_message()];
        }

        update_user_meta($novo_cliente_id, 'cpf_do_cliente', $cpf);
        $cliente_id = $novo_cliente_id;
    }

    // ----------------------------
    // 2. Criação de taxonomias, se necessário
    // ----------------------------
    $cidade_id = sanitize_text_field($_POST['tax_cidade'] ?? '');
    $emp_id    = sanitize_text_field($_POST['empreendimento'] ?? '');
    $apt_id    = sanitize_text_field($_POST['apartamento'] ?? '');

    if (!empty($_POST['novo_empreendimento_nome'])) {
        $term = wp_insert_term(sanitize_text_field($_POST['novo_empreendimento_nome']), 'empreendimento');
        if (!is_wp_error($term)) {
            $emp_id = $term['term_id'];
        }
    }

    if (!empty($_POST['novo_apartamento_nome'])) {
        $term = wp_insert_term(sanitize_text_field($_POST['novo_apartamento_nome']), 'apartamento');
        if (!is_wp_error($term)) {
            $apt_id = $term['term_id'];
        }
    }

    // ----------------------------
    // 3. Atualiza vínculos do cliente
    // ----------------------------
    if (!empty($cliente_id)) {
        update_user_meta($cliente_id, 'cidade_cliente', $cidade_id);
        update_user_meta($cliente_id, 'empreendimento_cliente', $emp_id);
        update_user_meta($cliente_id, 'apartamento_cliente', $apt_id);
    }

    // ----------------------------
    // 4. Criação do post IPTU
    // ----------------------------
    $titulo = sanitize_text_field($_POST['titulo'] ?? '');
    $post_id = wp_insert_post([
        'post_type'   => 'iptu',
        'post_title'  => $titulo,
        'post_status' => 'publish'
    ]);

    if (is_wp_error($post_id)) {
        return ['erro', 'Erro ao salvar documento.'];
    }

    if (function_exists('royal_log')) {
        royal_log($post_id, 'POST_ID IPTU');
        royal_log($_FILES, 'FILES_BEFORE_UPLOAD');
    }

    // ----------------------------
    // 5. Atualiza metadados
    // ----------------------------
    update_post_meta($post_id, 'gp_cliente', $cliente_id);
    update_post_meta($post_id, 'gp_status', 'pendente');
    update_post_meta($post_id, 'gp_vencimento', sanitize_text_field($_POST['vencimento'] ?? ''));

    // ----------------------------
    // 6. Atualiza taxonomias
    // ----------------------------
    if (!empty($cidade_id)) {
        wp_set_object_terms($post_id, intval($cidade_id), 'tax_cidade');
    }
    if (!empty($emp_id)) {
        wp_set_object_terms($post_id, intval($emp_id), 'empreendimento');
    }
    if (!empty($apt_id)) {
        wp_set_object_terms($post_id, intval($apt_id), 'apartamento');
    }

    // ----------------------------
    // 7. Upload do arquivo
    // ----------------------------
    if (!empty($_FILES['arquivo']['tmp_name'])) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $upload_id = media_handle_upload('arquivo', $post_id);

        if (!is_wp_error($upload_id)) {
            update_post_meta($post_id, '__uios_iptu_arquivo_para_download', $upload_id);
            if (function_exists('royal_log')) {
                royal_log(wp_get_attachment_url($upload_id), 'UPLOAD_URL');
            }
        } else {
            if (function_exists('royal_log')) {
                royal_log($upload_id->get_error_message(), 'UPLOAD_ERROR');
            }
        }
    }

    return ['sucesso', 'Documento cadastrado com sucesso!'];
}

// ----------------------------
// 8. Permissões de upload
// ----------------------------
function royal_add_upload_cap_to_roles() {
    foreach (['administrator', 'cliente'] as $role_name) {
        $role = get_role($role_name);
        if ($role && !$role->has_cap('upload_files')) {
            $role->add_cap('upload_files');
        }
    }
}
add_action('init', 'royal_add_upload_cap_to_roles');
add_action('admin_init', 'royal_add_upload_cap_to_roles');
