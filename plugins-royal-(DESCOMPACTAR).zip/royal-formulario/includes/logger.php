<?php
defined('ABSPATH') || exit;

function royal_log($data, $label = null) {
    $upload_dir = plugin_dir_path(__DIR__) . 'logs/';
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    $log_file = $upload_dir . 'debug.log';
    $timestamp = date('Y-m-d H:i:s');
    $prefix = $label ? "[$timestamp][$label]" : "[$timestamp]";

    $output = $prefix . ' ' . print_r($data, true) . PHP_EOL;
    file_put_contents($log_file, $output, FILE_APPEND);
}

royal_log($_POST, 'POST DATA');
royal_log($clientes, 'CLIENTES');
royal_log($cidades, 'CIDADES');