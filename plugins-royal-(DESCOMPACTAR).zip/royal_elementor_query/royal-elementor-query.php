<?php
/*
Plugin Name: Royal Elementor Custom Query + Filtro Cliente
Description: Filtra CPT 'iptu' por cliente (campo ACF 'gp_cliente'), suporta registros antigos/novos, Elementor Loop Grid, JetSmartFilters e admin visualizando todos os documentos.
Version: 2.1
Author: Sistema Royal
*/

if (!defined('ABSPATH')) exit;

// ==========================
// 1. Hook Elementor Query
// ==========================
add_action('elementor/query/cliente_documentos', function ($query) {

    if (!is_user_logged_in()) {
        $query->set('post__in', array(0));
        return;
    }

    $current_user = wp_get_current_user();
    $cliente_id = null;

    // Clientes logados
    if (in_array('cliente', (array)$current_user->roles, true)) {
        $cliente_id = $current_user->ID;
    }

    // Admin filtrando via GET
    elseif (in_array('administrator', (array)$current_user->roles, true) && isset($_GET['meta_query_gp_cliente']) && is_numeric($_GET['meta_query_gp_cliente'])) {
        $cliente_id = intval($_GET['meta_query_gp_cliente']);
    }

    $existing_meta_query = (array)$query->get('meta_query');

    if ($cliente_id) {
        // Filtra pelo ID do cliente (novo ou antigo)
        $existing_meta_query[] = array(
            'relation' => 'OR',
            array(
                'key'     => 'gp_cliente',
                'value'   => $cliente_id,
                'compare' => '='
            ),
            array(
                'key'     => 'gp_cliente',
                'value'   => '_' . $cliente_id,
                'compare' => 'LIKE'
            )
        );
        $query->set('meta_query', $existing_meta_query);
    }
    // Admin sem filtro GET vê todos
    elseif (in_array('administrator', (array)$current_user->roles, true)) {
        // Não adiciona meta_query, exibe todos
    }
    else {
        // Outros usuários sem permissão: bloqueia
        $query->set('post__in', array(0));
        return;
    }

    $query->set('post_type', 'iptu');
    $query->set('post_status', 'publish');
});

// ==========================
// 2. Shortcode do filtro para Admin
// ==========================
add_shortcode('filtro_cliente_acf', function () {
    if (!current_user_can('administrator')) return '';

    $clientes = get_users([
        'role'   => 'cliente',
        'fields' => ['ID', 'display_name']
    ]);

    $selected = isset($_GET['meta_query_gp_cliente']) ? intval($_GET['meta_query_gp_cliente']) : '';

    ob_start(); ?>
    <form method="get" id="filtro-cliente-form" style="margin-bottom: 20px;">
        <label for="meta_query_gp_cliente"><strong>Filtrar por cliente:</strong></label>
        <select name="meta_query_gp_cliente" id="meta_query_gp_cliente" onchange="this.form.submit();">
            <option value="">Todos</option>
            <?php foreach ($clientes as $cliente): ?>
                <option value="<?= esc_attr($cliente->ID) ?>" <?= selected($selected, $cliente->ID, false) ?>>
                    <?= esc_html($cliente->display_name) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </form>
    <?php return ob_get_clean();
});

// ==========================
// 3. Função opcional para normalizar registros antigos
// ==========================
function royal_normalizar_gp_cliente() {
    $posts = get_posts([
        'post_type'      => 'iptu',
        'posts_per_page' => -1,
        'fields'         => 'ids',
    ]);

    foreach ($posts as $post_id) {
        $valor = get_post_meta($post_id, 'gp_cliente', true);

        if ($valor && !is_numeric($valor)) {
            if (preg_match('/_(\d+)$/', $valor, $matches)) {
                update_post_meta($post_id, 'gp_cliente', intval($matches[1]));
            }
        }
    }
}
// royal_normalizar_gp_cliente(); // descomente e rode 1 vez para normalizar registros antigos
