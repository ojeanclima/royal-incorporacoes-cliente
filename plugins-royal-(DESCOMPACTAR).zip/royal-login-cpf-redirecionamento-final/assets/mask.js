jQuery(document).ready(function($){
    $('#cpf').on('input', function() {
        var value = $(this).val().replace(/\D/g, '');
        if (value.length > 3) value = value.replace(/^(\d{3})/, '$1.');
        if (value.length > 7) value = value.replace(/^(\d{3})\.(\d{3})/, '$1.$2.');
        if (value.length > 11) value = value.replace(/^(\d{3})\.(\d{3})\.(\d{3})/, '$1.$2.$3-');
        $(this).val(value);
    });

    var documentoMaskBehavior = function (val) {
        return val.replace(/\D/g, '').length === 11 ? '000.000.000-00' : '00.000.000/0000-00';
    },
    documentoOptions = {
        onKeyPress: function(val, e, field, options) {
            field.mask(documentoMaskBehavior.apply({}, arguments), options);
        }
    };

    $('#documento').mask(documentoMaskBehavior, documentoOptions);
});
