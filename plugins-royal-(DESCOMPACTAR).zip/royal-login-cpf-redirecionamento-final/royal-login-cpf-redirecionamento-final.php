<?php
/**
 * Plugin Name: Royal Login CPF/CNPJ + Redirecionamento (Final)
 * Description: Login por CPF/CNPJ com normalização de dados, máscara e estilo embutido.
 * Version: 1.8.0
 * Author: Sistema Royal
 */

if (!defined('ABSPATH')) exit;

// Iniciar sessão
add_action('init', function() {
    if (!session_id()) session_start();
});

// Carregar scripts e styles
add_action('wp_enqueue_scripts', function() {
    wp_enqueue_script('jquery');
    wp_enqueue_script('jquery-mask', 'https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js', array('jquery'), null, true);
    wp_enqueue_script('royal-cpf-cnpj-mask', plugin_dir_url(__FILE__) . 'assets/mask.js', array('jquery', 'jquery-mask'), null, true);
    wp_enqueue_style('royal-login-cpf-cnpj-style', plugin_dir_url(__FILE__) . 'assets/style.css');
});

// Shortcode do formulário
add_shortcode('royal_login_cpf_cnpj', function () {
    ob_start();
    if (!empty($_SESSION['royal_login_error'])) {
        echo '<div class="royal-login-error">' . esc_html($_SESSION['royal_login_error']) . '</div>';
        unset($_SESSION['royal_login_error']);
    }
    ?>
    <form method="post" id="royal-login-form" class="royal-login-form">
        <div class="form-group">
            <label for="documento">CPF ou CNPJ:</label>
            <input type="text" id="documento" name="documento" required placeholder="000.000.000-00 ou 00.000.000/0000-00">
        </div>

        <input type="hidden" name="royal_login_nonce" value="<?php echo wp_create_nonce('royal_login_action'); ?>">

        <button type="submit" class="royal-login-button">Entrar</button>
    </form>
    <?php
    return ob_get_clean();
});

// Processar login
add_action('init', function () {
    if (isset($_POST['documento'], $_POST['royal_login_nonce'])) {
        if (!wp_verify_nonce($_POST['royal_login_nonce'], 'royal_login_action')) wp_die('Ação não autorizada.');

        $documento_input = preg_replace('/\D/', '', sanitize_text_field($_POST['documento']));

        $user_query = new WP_User_Query([
            'meta_query' => [
                'relation' => 'OR',
                ['key' => 'cpf_do_cliente', 'compare' => 'EXISTS'],
                ['key' => 'cnpj_do_cliente', 'compare' => 'EXISTS'],
            ],
            'number' => -1,
            'count_total' => false,
        ]);

        $users = $user_query->get_results();
        if (!empty($users)) {
            foreach ($users as $user) {
                $cpf_user = preg_replace('/\D/', '', get_user_meta($user->ID, 'cpf_do_cliente', true));
                $cnpj_user = preg_replace('/\D/', '', get_user_meta($user->ID, 'cnpj_do_cliente', true));

                if ($documento_input === $cpf_user || $documento_input === $cnpj_user) {
                    wp_set_current_user($user->ID);
                    wp_set_auth_cookie($user->ID);
                    do_action('wp_login', $user->user_login, $user);
                    wp_redirect(home_url('/dashboard'));
                    exit;
                }
            }
        }

        $_SESSION['royal_login_error'] = 'CPF ou CNPJ incorreto.';
        wp_redirect($_SERVER['REQUEST_URI']);
        exit;
    }
});

// Redirecionamentos pós-login
add_filter('login_redirect', function($redirect_to, $request, $user) {
    if (isset($user->roles) && is_array($user->roles)) return home_url('/dashboard');
    return $redirect_to;
}, 10, 3);

add_action('init', function() {
    if (is_user_logged_in() && ($GLOBALS['pagenow'] === 'wp-login.php' || $GLOBALS['pagenow'] === 'wp-register.php')) {
        wp_redirect(home_url('/dashboard'));
        exit;
    }
});

add_action('template_redirect', function() {
    if (is_user_logged_in() && is_front_page() && !is_admin()) {
        wp_redirect(home_url('/dashboard'));
        exit;
    }
});

// Logout customizado
add_action('init', function () {
    if (isset($_GET['royal_logout']) && $_GET['royal_logout'] === 'true') {
        // Realizar logout nativo do WP
        wp_logout();

        // Finalizar sessão PHP
        if (session_status() === PHP_SESSION_NONE) session_start();
        session_unset();
        session_destroy();

        // Expirar cookies manualmente
        setcookie('wordpress_logged_in_' . COOKIEHASH, '', time() - 3600, COOKIEPATH, COOKIE_DOMAIN);
        setcookie('wordpress_sec_' . COOKIEHASH, '', time() - 3600, COOKIEPATH, COOKIE_DOMAIN);

        // Redirecionar para login
        wp_redirect(home_url('/login'));
        exit;
    }
});
?>
